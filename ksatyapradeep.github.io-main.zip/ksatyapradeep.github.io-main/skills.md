# 🧰 Skills
**Languages/Tools:** SQL, Python (Pandas, NumPy, Matplotlib, scikit-learn), R, SAS  
**BI:** Power BI, Tableau, QuickSight  
**Data Eng:** Snowflake, Informatica, Collibra, ETL, AWS (S3, EC2, Redshift)

### Badges
![Power BI](https://img.shields.io/badge/Microsoft-Power%20BI-yellow?logo=powerbi)
![Tableau](https://img.shields.io/badge/Tableau-Analyst-blue?logo=tableau)
![AWS](https://img.shields.io/badge/AWS-Data%20Analytics-orange?logo=amazonaws)
![Python](https://img.shields.io/badge/Python-Data%20Science-blue?logo=python)
![SQL](https://img.shields.io/badge/SQL-Advanced-lightgrey)
