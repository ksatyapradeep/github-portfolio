# 👨‍💼 About
I’m a Data Analyst focused on BI & analytics for insurance, logistics, and healthcare. I love building dashboards that drive action.

**Contact:** kodeboinapradeep@gmail.com
