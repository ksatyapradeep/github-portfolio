# 🏅 Certifications
- Microsoft Power BI (PL-300) — [Credential](#)
- Tableau Data Analyst — [Credential](#)
- AWS Data Analytics — [Credential](#)
